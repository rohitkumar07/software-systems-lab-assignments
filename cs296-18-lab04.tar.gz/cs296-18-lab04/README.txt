
------------------------------------------------------------------------------------
Assignment 4 - DIFF AND PATCH, SOURCE VERSION CONTROL USING SVN AND GIT
------------------------------------------------------------------------------------ 

Group No-18

1.Rohit Kumar 120050028
2.Suman Sourabh 120050031
3.Nitin Chandrol 120050035
------------------------------------------------------------------------------------

We have taken care of all plagiarism policies and whole assignment is our work.
For learning and implementing different svn/git tags we have referred these sites-

1. SVN cheat sheet :- http://www.abbeyworkshop.com/howto/misc/svn01/
2. Stack Overflow :- Querying website
3. Git - SVN Crash Course :- http://git.or.cz/course/svn.html
4. Git simple giude :- http://rogerdudler.github.io/git-guide/
5. Box2D manual :- for learning about b2World and b2Profile data types
6. Last but not the least, Google!
