
------------------------------------------------------------------------------------
Assignment 7 - Timing and Profiling Code
------------------------------------------------------------------------------------ 

Group No-18

1.Rohit Kumar 120050028
2.Suman Sourabh 120050031
3.Nitin Chandrol 120050035
------------------------------------------------------------------------------------

Note :- All the graphs added in report are graph generated over small data points

------------------------------------------------------------------------------------

I have taken care of all plagiarism policies as whole assignment is done by us.
For learning and implementing  we have referred these sites-

1. gprof tutorial :- http://www.thegeekstuff.com/2012/08/gprof-tutorial/
2. Manual pages of commands
3. Profiling on linux
4. Stack Overflow :- Querying website
------------------------------------------------------------------------------------

