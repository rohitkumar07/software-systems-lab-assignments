#!/bin/bash

find $1 | wc -l
find $1 -executable -type f
