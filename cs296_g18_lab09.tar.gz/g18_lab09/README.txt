
------------------------------------------------------------------------------------
Assignment 9 - PYTHON PROGRAMMING
------------------------------------------------------------------------------------ 

Group No-18

1.Rohit Kumar 120050028
2.Suman Sourabh 120050031
3.Nitin Chandrol 120050035

------------------------------------------------------------------------------------

I have taken care of all plagiarism policies as whole assignment is done by us.
For learning and implementing, we have referred these sites-

1. http://docs.python.org/3/tutorial/
2. http://matplotlib.org/ 	- Matplotlib official website
3. Stack Overflow :- Querying website
------------------------------------------------------------------------------------

