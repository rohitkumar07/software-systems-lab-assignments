
------------------------------------------------------------------------------------
Assignment 5 - Bash Shell Scripting and Gnuplot
------------------------------------------------------------------------------------ 

Group No-18

1.Rohit Kumar 120050028
2.Suman Sourabh 120050031
3.Nitin Chandrol 120050035
------------------------------------------------------------------------------------

We have taken care of all plagiarism policies and whole assignment is our work.
For learning and implementing different Shell and Gnuplot commands we have referred these sites-

1. Bash Scripting Guide :- http://tldp.org/LDP/abs/html/
2. Linux Bash Tutorial :- http://www.linuxjournal.com/content/
3. Gnuplot Demos :- http://gnuplot.sourceforge.net/demo/index.html
4. Sed Introduction :- http://www.grymoire.com/Unix/Sed.html
5. Stack Overflow :- Querying website
6. Last but not the least, Google!
