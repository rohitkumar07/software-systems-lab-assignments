
------------------------------------------------------------------------------------
Assignment 6 - SHELL SCRIPTING AND GENERAL LINUX UNDERSTANDING
------------------------------------------------------------------------------------ 

Group No-18

1.Rohit Kumar 120050028
2.Suman Sourabh 120050031
3.Nitin Chandrol 120050035
------------------------------------------------------------------------------------

Note :- For, 5th part ,for running backup.sh argument should be directory where pendrive
 is mounted for example - /media/usr_name/pen_drive_name

------------------------------------------------------------------------------------

I have taken care of all plagiarism policies as whole assignment is done by us.
For learning and implementing various shell commands we have referred these sites-

1. Bash Scripting Guide :- http://tldp.org/LDP/abs/html/
2. Manual pages of commands
3. Sed Introduction :- http://www.grymoire.com/Unix/Sed.html
4. Sed Introduction :- http://www.grymoire.com/Unix/Awk.html
5. Stack Overflow :- Querying website
------------------------------------------------------------------------------------

